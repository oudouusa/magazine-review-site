# Handoff: MODEL HUB — Gravure Magazine & Photobook Affiliate Site

## Overview

**MODEL HUB** is a collector-focused affiliate site that introduces gravure magazines and photobooks to readers, with purchase links to Amazon, 楽天ブックス, and DMM (FANZA). The site emphasizes:

- **Archive depth** — backnumber catalog reaching back to the 2010s, out-of-print/reissue tracking
- **Editorial voice** — magazine-style layouts, 明朝 (Mincho) serif typography, "編集部" curation
- **Restrained monetization** — one primary buy button per card, small "PR" labels, no fake prices/urgency
- **3-way price comparison** — Amazon / 楽天 / FANZA side by side on detail pages

The target audience is **collectors** (people who track backnumbers, photobook editions, signed/limited items) — not casual readers. Copy and IA reflect this (e.g., "初版の見分け方" feature, "復刻・絶版" filter).

This handoff covers **all 7 site pages** as static HTML prototypes:

| File | Page | Purpose |
|---|---|---|
| `Home.html` | トップ | Hero (3 variants) + latest issues + TOP10 ranking + editor's pick + browse + new arrivals + features. Includes Tweaks panel. |
| `Model.html` | モデル詳細 | Profile (DOB / height / agency) + appearance timeline + popular photobooks + related models |
| `Magazine.html` | 雑誌・写真集詳細 | Cover + 3-way price comparison table (Amazon / 楽天 / FANZA) + TOC + spec + backnumber carousel |
| `Models.html` | モデル一覧 | 五十音 grouped grid + facet sidebar + pagination |
| `Magazines.html` | 雑誌・写真集一覧 | Type tabs + month-grouped grid + facet sidebar |
| `Ranking.html` | ランキング | Podium (TOP3) + numbered list (4-30) + Hall of Fame |
| `Feature.html` | 特集記事 | Editorial long-form article with inline product cards |

---

## About the Design Files

The files in this bundle (`Home.html`, `styles.css`, `tweaks-panel.jsx`) are **design references created in HTML** — prototypes showing intended look and behavior. They are **not production code** and should not be shipped directly.

The implementation task is to **recreate these designs in the target codebase's existing environment** (Next.js, Astro, Rails, etc.) using its established patterns, component libraries, and routing conventions. If no codebase exists yet, choose an appropriate framework for an editorial/affiliate site — **Next.js with App Router + Tailwind**, or **Astro**, would both be excellent fits given the content-heavy, SEO-sensitive nature of this product.

The HTML/CSS reflects exact spacing, typography, colors, and component composition the implementation should match.

---

## Fidelity

**High-fidelity (hifi).** Pixel-perfect mockups with final colors, typography, spacing, and interactions are defined. The developer should recreate the UI pixel-perfectly. Three theme variants (Sakura / Navy / Mono) and three density variants (Loose / Normal / Dense) are part of the spec — implement them as user-switchable preferences.

Note: portrait images, magazine covers, and editorial photography are represented by CSS gradient placeholders in this prototype. The implementation will need real assets (delivered via CMS or the affiliate partner's product feed).

---

## Layout System

The composition shown in the prototype is a **canvas-style design document** (1640px wide, with the desktop site + 2 phone frames + a features strip side by side). **The desktop site is the actual web product (1080px content-width).** The phone frames and features strip exist only to communicate the responsive design and the value-prop summary — they are not part of the shipping site.

### Desktop Web Product

- **Content width**: 1080px (centered, with breathing room at viewport edges)
- **Sections** flow top-to-bottom in this order:
  1. Nav (logo + main menu + search + heart/user icons)
  2. Sub-nav (棚から探す — shelf shortcuts)
  3. Hero (one of three variants — see Tweaks)
  4. Latest Issues spotlight (1 large + 4 small magazine cards)
  5. Monthly Trending — Models TOP 10 (2 rows × 5 cards)
  6. Editor's Pick — Photobooks (1 large feature + 3 stacked cards)
  7. Browse by Genre (12 large tags, 6 columns)
  8. New Arrivals — Photobooks (6 columns)
  9. Feature Articles preview (3 cards)
  10. Newsletter signup
  11. Footer

### Mobile

- Viewport: ~360px width (iPhone-class)
- Same content sections, reorganized:
  - Mobile hero compresses the latest-issue feature
  - Latest issues become a horizontal scroller (snap-to-start)
  - Ranking shows the top 5 as a vertical list (rest behind "全部見る")
  - Editor's Pick becomes a single-column hero card
  - Genre browse becomes a 3-column grid
- Bottom tab bar: ホーム / 探す / ランキング / お気に入り / マイ

### Breakpoints (recommended)

The prototype is desktop-only. For implementation:
- `< 640px` — mobile (see Mobile sketches in `Home.html`)
- `640–1024px` — tablet (single column, slightly larger than mobile)
- `1024–1280px` — small desktop (compress nav, reduce some grids)
- `≥ 1280px` — full desktop (the prototype's layout)

---

## Screens

### 1. Desktop Home (`<section class="site">` in Home.html)

#### Nav (`.nav`)

- Background: `var(--paper)` (#ffffff in default sakura theme)
- Border-bottom: `1px solid var(--line)`
- Padding: `18px 28px`
- Three-column grid: logo (auto) / menu (centered, 1fr) / right cluster (auto)

**Logo** (`.logo`)
- 42×42 circular mark — radial gradient (cream → rose-3 → rose-2) with 5-petal SVG inside
- Title: `MODEL HUB` — Noto Serif JP 600, 19px, letter-spacing .12em
- Subtitle: `GRAVURE MAGAZINE & PHOTOBOOK ARCHIVE` — 9.5px, letter-spacing .28em, color `var(--ink-3)`

**Menu** (`.nav-menu`)
- 6 links: トップ / モデル / 雑誌・写真集 / ランキング / 特集 / バックナンバー
- Noto Serif JP, 13.5px, letter-spacing .14em
- Active link: color `var(--primary)`, with small primary-colored dot appended
- Hover: `background: var(--rose-3); color: var(--plum);`

**Right cluster** (`.nav-right`)
- Pill-shaped search input (220px wide, placeholder: "モデル名・雑誌名・誌名から探す")
- 36×36 circular "heart" button with notification badge ("12")
- 36×36 circular "user" button

#### Sub-nav (`.subnav`)

- Background: `var(--paper-2)`, horizontal scroller, 11.5px font
- Label "棚から探す" followed by 8 shelf categories separated by vertical hairlines
- Right-aligned "最終更新 2026/05/24" indicator

#### Hero (`.hero`) — THREE VARIANTS

Switched by `data-hero` attribute on `.site` (controlled by Tweaks). Only one is visible at a time; CSS rules in `styles.css` hide the inactive two.

**Common to all variants:**
- Background: `var(--hero-grad)` (theme-dependent multi-stop linear gradient)
- Eyebrow: "FEATURED ISSUE — 今週のスポットライト" with `[PR]` mini-tag
- Two blurred glow circles (`::before` / `::after`) using `var(--hero-glow1)` / `var(--hero-glow2)`

**Variant A — `cover` (default)** (`.hero-cover`)
- Two-column layout (1.1fr / 1fr)
- Left: H1 title with `<em>` highlighted in `var(--primary)`, lede paragraph (max 460px), 4 credit items (誌名 / 号数 / 発売 / 掲載), 3 CTA buttons (Amazon orange / 楽天 red / FANZA ghost)
- Right: One large magazine cover (320px, rotate -2deg, layered shadows) + two smaller "mini covers" rotated and offset

**Variant B — `portrait`** (`.hero-portrait`)
- Two-column layout (380px / 1fr)
- Left: Vertical 3:4 model portrait with floating issue chips on the right edge
- Right: Eyebrow "MODEL OF THE WEEK" + 60px serif model name + reading (yomi) + 3 tags + lede + 3-stat row (出演誌 / 写真集 / 今月ランキング) + 3 CTA buttons

**Variant C — `collage`** (`.hero-collage`)
- Two-column layout (1fr / 1.1fr)
- Left: H1 "今週の5冊を、編集部が読み解く" + lede + 3 credits + 2 CTA buttons
- Right: A 420px-tall collage stage with 5 magazine-cover "pieces" positioned absolutely with varying rotations (-4° to +6°), z-indexes, and dimensions

#### Latest Issues Spotlight (`.spotlight`)

3-column grid (1.4fr / 1fr / 1fr):
- **Left (`.sl-hero`)**: Spans 2 rows. Large 3:4 magazine cover with masthead + feature text overlay, then meta row (誌名・号数・発売日), title (Noto Serif JP 600, 18px), model chip (with circular "朝" avatar), price + PR tag + "Amazonで買う" CTA.
- **Right (4 × `.sl-item`)**: Each is a horizontal card with 96px mini-cover thumbnail on left and body on right. Body shows meta, title (clamped to 2 lines), price, and small "楽天で買う" / "Amazon" pill on the right.

#### TOP 10 Ranking (`.ranking`)

Two `.ranking` rows of 5 cards each. Each `.rank-card`:
- 3:4 portrait gradient block at top
- Large rank number (56px serif, gold/silver/bronze gradient for ranks 1-3 via background-clip:text)
- Trend pill in top-right (`up` green / `down` muted red / `new` amber)
- Body: Name (Noto Serif JP, 15px), reading, tag chips, foot row with "出演 / 写真集" stats

Trend variants and their colors:
- `up`: `background: rgba(107,143,107,.85)` (leaf green)
- `down`: `background: rgba(180,90,80,.7)` (dusty red)
- `new`: `background: rgba(201,138,58,.92)` (amber)

#### Editor's Pick (`.pickup`)

Two-column grid (1.3fr / 1fr):

**Left (`.pk-hero`)** — Editor's #1 photobook
- Inner grid (1.05fr / 1fr):
  - Cover stage: Hero gradient bg, large 220px-wide photobook cover, rotated -3°
  - Meta panel: PR-amber eyebrow "★ FEATURED PHOTOBOOK", title (Noto Serif JP, 22px), author/photographer/publisher row, blockquote with rose-colored left border, 3 inline stats (ページ数 / 発売日 / 形態), price row with bottom-dashed border, then 2 buy CTAs (Amazon + 楽天)

**Right (`.pickup-list`)** — 3 stacked smaller cards
- Each has a 96px mini-cover (with small "02" / "03" / "04" rank in bottom-left) + body (genre eyebrow, title, footer with date + price)

#### Browse by Genre (`.browse`)

12-card grid (6 columns) of `.bw-card`:
- 4:5 aspect ratio
- Linear gradient bg (two CSS vars `--c1` / `--c2`) with darkening overlay at bottom
- White serif label in bottom-left: title (14px, .08em) + count (9.5px, .18em)
- Hover: translateY(-2px)

#### New Arrivals (`.arrivals`)

6-card grid of `.ar-card`:
- 3:4 cover with gradient
- Color-coded badge in top-left: `予約` (amber), `新刊` (leaf green), `復刻` (amber)
- Below cover: 発売日 (10px), model name (Noto Serif JP, 13px), price + shop pill

#### Feature Articles (`.features-grid`)

3-card grid of `.feat-card`:
- 16:9 image with white-pill tag in top-left (e.g., "解説" / "インタビュー" / "特集")
- Body: date + author meta, title (Noto Serif JP, 16px), 2-line clamped lede

#### Newsletter (`.newsletter`)

- Hero-gradient pill bar with blurred glow
- Two-column: left text (eyebrow + title + sub), right pill-form (email input + 登録 button)

#### Footer (`.site-foot`)

- White background, top border
- 4 link columns (EXPLORE / COLLECTION / ABOUT / LEGAL) + right-aligned brand block with the **PR disclosure pill** ("本サイトはアフィリエイト広告を掲載しています")

---

### 2. Mobile Home (Phone 1 in Home.html)

- iPhone-class status bar + dynamic island
- `.m-nav`: logo + search/heart/menu icons
- `.m-hero`: vertical hero with centered 130px cover, 2-button CTA row
- Horizontal mag scroller (`.m-h-scroll`) — 138px wide cards with snap
- Mobile ranking list (`.m-rank-list`) — 5 rows of: rank number + 60px square portrait + name/meta + trend pill
- Mobile pickup card (`.m-pickup`) — full-width, hero-gradient cover stage on top + body below
- Mobile browse grid (3×2) — 4:3 chips
- PR disclosure pill at bottom
- Tab bar (5 items): ホーム / 探す / ランキング / お気に入り / マイ

### 3. Mobile Magazine Detail (Phone 2 in Home.html)

A glimpse of the *destination* — what users land on after tapping a magazine.

- Back arrow + "最新号" label nav
- Big 180px cover on hero-gradient background, with eyebrow + 誌名 + 号数 + 発売日 below
- Price row (large serif yen + ￥520 + 税込ラベル) + PR small text
- 3 vertical-stacked buy buttons: Amazon (orange) / 楽天ブックス (red) / FANZA (pink) — each with mini PR label
- 登場モデル chip row
- 特集内容 bulleted list (4 items)
- 基本情報 key-value table (出版社・発売日・判型・ページ数・電子版・バックナンバー)
- PR disclosure pill at bottom

---

## Interactions & Behavior

### Hero variant switching (Tweaks)

- Only one variant rendered visually at a time
- Switch updates `data-hero="cover|portrait|collage"` on the site root
- CSS handles visibility via `.site[data-hero="X"] .hero-Y { display: none; }`
- Transition: none (instant swap) — acceptable for this prototype, but production may want a 200ms cross-fade

### Theme switching (Tweaks)

- 3 themes: `sakura` (default) / `navy` / `mono`
- Switch updates `data-theme="..."` on `<body>`
- Theme-scoped CSS custom properties cascade through everything (see *Design Tokens*)
- Consider persisting theme to localStorage and respecting `prefers-color-scheme` if you later add a dark variant

### Density switching (Tweaks)

- 3 modes: `loose` / `normal` / `dense`
- Switch updates `data-density="..."` on `<body>`
- Drives 4 CSS vars: `--pad`, `--gap`, `--row-gap`, `--card-pad`
- Loose: 28 / 22 / 36 / 22
- Normal: 20 / 16 / 28 / 16
- Dense: 14 / 10 / 20 / 12

### Hover states

- Magazine cards (spotlight small items, arrivals, pickup small items): `translateY(-1px to -2px)` + optional shadow lift
- Nav links: background tint to `var(--rose-3)` (or theme equivalent)
- Buttons: `filter: brightness(1.05)` on hover

### Affiliate buttons

The site uses **partner brand colors** for primary buy buttons (this is the convention for Japanese affiliate sites and feels appropriate here):

| Class | Background | Color | Use |
|---|---|---|---|
| `.btn-amazon`  | `#ff9900` | `#1a1a1a` | Amazon link |
| `.btn-rakuten` | `#bf0000` | white     | 楽天ブックス link |
| `.btn-fanza`   | `#f43c4d` | white     | FANZA (DMM) link |
| `.btn-ghost`   | white     | `var(--ink-2)` | Secondary action |
| `.btn-primary` | `var(--primary)` | white | Site CTAs (詳細を見る, etc.) |

All affiliate buttons include a small `.pr-mini` label inside them ("PR") — keep this for compliance.

### PR disclosure

- Small "PR" text appears on each card with an affiliate link
- A larger disclosure pill ("本サイトはアフィリエイト広告を掲載しています") appears in the footer and mobile feeds
- Per Japanese law / 消費者庁 stealth marketing rules, this disclosure **must be visible without scrolling on any page with affiliate links**. Implementation should add a small header banner if affiliate links appear above the fold.

### Scroll behavior

- The horizontal mag scroller on mobile uses CSS `scroll-snap-type: x mandatory` with each card `scroll-snap-align: start`
- No infinite scroll anywhere — pagination/load-more is expected on list pages

---

## State Management

For the home page specifically:

- **User preferences** (theme / density / hero variant) — persist to localStorage and SSR-rehydrate to avoid flash of wrong theme
- **Heart/favorites count badge** — read from authenticated user's favorites list; show 0/hide when logged out
- **Newsletter signup** — single email field, POST to newsletter service

For the broader site (future pages):

- **Affiliate links** — generated server-side from a product table with `{partner, asin/jan, affiliate_id, url}` records. **Do not** put affiliate IDs in client JS.
- **Price/stock display** — fetch from partner APIs (Amazon PA-API, 楽天 Books API, DMM API) with appropriate caching (15–60min depending on partner ToS). Show `--` if unavailable, never fake a price.
- **Ranking** — computed nightly from a click/view/favorite signal, served as static or ISR-cached
- **"New" / "予約" / "復刻" badges** — derived from product metadata (release_date vs now, edition_type field)

---

## Design Tokens

All tokens live in `:root` / `[data-theme="..."]` selectors in `styles.css`. Mirror these in your design tokens / Tailwind config.

### Color tokens (per theme)

#### Sakura (default)

| Token | Value | Use |
|---|---|---|
| `--bg` | `#fbf8f6` | Page background |
| `--bg-2` | `#f5ece8` | Canvas/outer background |
| `--paper` | `#ffffff` | Card/nav background |
| `--paper-2` | `#faf6f3` | Subtle paper tint (sub-nav, inputs) |
| `--ink` | `#2a1f24` | Primary text |
| `--ink-2` | `#5b4e54` | Secondary text |
| `--ink-3` | `#8e8087` | Tertiary text / labels |
| `--line` | `#ece5e2` | Borders |
| `--line-2` | `#f4eeeb` | Inner borders / dashed dividers |
| `--primary` | `#6c5b8c` | Plum/purple — editorial accent |
| `--primary-2` | `#efeaf6` | Primary tint |
| `--rose` | `#e8a8b8` | Sakura pink |
| `--rose-2` | `#f5d4dc` | Lighter rose |
| `--rose-3` | `#fbe9ee` | Lightest rose tint |
| `--plum` | `#7a4a5a` | Magazine/category emphasis |
| `--amber` | `#c98a3a` | Gold / 編集部 / 予約badge |
| `--leaf` | `#6b8f6b` | "新刊" green / up-trend |
| `--pr` | `#c98a3a` | "PR" label color |

#### Navy

| Token | Value |
|---|---|
| `--bg` | `#f6f4ef` |
| `--bg-2` | `#ecead8` |
| `--paper` | `#fefdf9` |
| `--paper-2` | `#f5f1e6` |
| `--ink` | `#16223a` |
| `--ink-2` | `#44516d` |
| `--ink-3` | `#8a92a6` |
| `--line` | `#dfdacb` |
| `--primary` | `#1a3a6e` |
| `--primary-2` | `#e6ecf6` |
| `--rose` | `#c4945a` (warm champagne) |
| `--rose-2` | `#ead8b8` |
| `--rose-3` | `#f5ecd8` |
| `--plum` | `#2c4870` |
| `--amber` | `#b87d35` |
| `--pr` | `#b87d35` |

#### Mono

| Token | Value |
|---|---|
| `--bg` | `#f7f5f1` |
| `--bg-2` | `#ece8df` |
| `--paper` | `#fefdf9` |
| `--paper-2` | `#f3efe6` |
| `--ink` | `#1a1614` |
| `--ink-2` | `#4a4338` |
| `--ink-3` | `#8a8275` |
| `--line` | `#e3ddce` |
| `--primary` | `#1a1614` |
| `--rose` | `#9a8a78` |
| `--plum` | `#3a3024` |
| `--amber` | `#6a5640` |
| `--pr` | `#6a5640` |

### Affiliate partner colors (theme-invariant)

| Token | Value |
|---|---|
| Amazon | `#ff9900` background, `#1a1a1a` text |
| 楽天   | `#bf0000` background, white text |
| FANZA  | `#f43c4d` background, white text |

### Hero gradients (theme-scoped)

| Theme | `--hero-grad` |
|---|---|
| Sakura | `linear-gradient(120deg, #fdf2f1 0%, #f8eeee 50%, #f3e9f0 100%)` |
| Navy | `linear-gradient(120deg, #ecead8 0%, #e0dac0 50%, #d2cfb8 100%)` |
| Mono | `linear-gradient(120deg, #ede8dc 0%, #dcd4c2 50%, #c8bfac 100%)` |

### Spacing (density-scoped)

| Density | `--pad` | `--gap` | `--row-gap` | `--card-pad` |
|---|---|---|---|---|
| Loose  | 28px | 22px | 36px | 22px |
| Normal | 20px | 16px | 28px | 16px |
| Dense  | 14px | 10px | 20px | 12px |

### Typography scale

| Element | Family | Size | Weight | Letter-spacing |
|---|---|---|---|---|
| H1 hero title | Noto Serif JP | 42–60px | 600 | .06–.14em |
| H1 hero name (portrait) | Noto Serif JP | 60px | 600 | .14em |
| H2 section title | Noto Serif JP | 26px | 600 | .12em |
| H3 spotlight title | Noto Serif JP | 18px | 600 | .04em |
| H3 newsletter title | Noto Serif JP | 22px | 600 | .10em |
| H4 small card title | Noto Serif JP | 13–16px | 600 | .04em |
| Section eyebrow | Noto Serif JP | 10px | 400 | .32em |
| Logo title | Noto Serif JP | 19px | 600 | .12em |
| Logo subtitle | Noto Sans JP | 9.5px | 400 | .28em |
| Nav links | Noto Serif JP | 13.5px | 400 | .14em |
| Body lede | Noto Sans JP | 13px | 400 | .04em, line-height 1.85 |
| Card body | Noto Sans JP | 11–12.5px | 400 | .04em, line-height 1.65–1.7 |
| Meta / dates | Noto Serif JP | 10–11px | 400 | .04–.08em |
| Button | Noto Sans JP | 13px | 600 | .04em |
| PR mini-label | Noto Sans JP | 9px | 600 | .15em |

**Font feature**: `font-feature-settings: "palt" 1;` enables proportional alternates for Japanese — keeps spacing natural in mixed JP/EN runs.

### Other tokens

| Token | Value |
|---|---|
| Card border-radius | `12–14px` (cards), `10px` (compact), `5–6px` (covers), `999px` (pills) |
| Card shadow | `0 1px 2px rgba(60,30,40,.04)` (rest), `0 6px 18px rgba(80,50,40,.08)` (hover) |
| Cover shadow | `0 14–22px 30–44px rgba(80,50,40,.18–.22)` |
| Hero shadow | `0 30px 60px rgba(60,30,40,.10), 0 2px 8px rgba(60,30,40,.05)` |

---

## Assets

The prototype uses **no real images** — all magazine covers, portraits, and editorial photos are CSS linear-gradient placeholders with `--c1` / `--c2` color variables driving their look.

For implementation you'll need:

| Asset type | Source | Notes |
|---|---|---|
| Magazine cover images | Affiliate partner product APIs (Amazon PA-API `MediumImage`, 楽天 `mediumImageUrls`, DMM API) | Cache locally; respect partner ToS for image hosting. |
| Model portraits | Editorial team uploads (probably via CMS) or pulled from a model-profile DB | Need consent + rights documented; consider WebP + AVIF, lazy load below the fold |
| Photobook covers | Same as magazine covers | Often higher-quality stills available in publisher press kits |
| Feature article hero images | Editorial-team supplied | 16:9 crop, store original + responsive variants |
| Site logo (sakura mark) | Inline SVG — see `Home.html` `.brand-mark svg` | Already in the HTML; lift directly |
| Icon library | Inline `<symbol>` definitions in `Home.html` — `i-search`, `i-heart`, `i-user`, `i-menu`, `i-home`, `i-book`, `i-grid`, `i-crown`, `i-bookmark`, `i-pen`, `i-sparkle`, `i-archive`, `i-tag`, `i-shield`, `i-cart`, `i-arrow` | Replace with Lucide or Heroicons if your stack uses one — they're close visual matches. Or extract the SVG paths. |

### Fonts

- **Noto Sans JP** (weights 400/500/600/700)
- **Noto Serif JP** (weights 400/500/600/700)

Both loaded from Google Fonts in the prototype. In production:
- Self-host or use `@fontsource/noto-sans-jp` + `@fontsource/noto-serif-jp` for predictable loading
- Subset to Japanese + Latin to reduce payload (full Noto fonts are huge)
- Apply `font-display: swap` and preload the most-used weight (600 for serif)

---

## Implementation Notes

### Suggested stack

If starting fresh, **Next.js (App Router) + Tailwind + a small headless CMS** would map naturally:

- Server Components for SEO-critical content (everything on the home page)
- Image component for portrait/cover lazy-loading + responsive variants
- Tailwind config: port the design tokens above into `theme.extend.colors` / `spacing` / `fontFamily`
- Theme switching via `data-theme` attribute on `<html>` (Tailwind v4 supports `@variant` selectors on attribute values cleanly; v3 use a darkMode-equivalent plugin)
- Density variants likely handled as Tailwind config but switchable via CSS custom props is also fine — the prototype's `--pad` / `--gap` approach works in any stack

### Component breakdown (suggested)

For React/Vue:

```
<SiteNav />          — top nav row
<ShelfNav />         — sub-nav with shelf categories
<Hero variant="..."> — accepts "cover" | "portrait" | "collage"
<SpotlightSection issues={...} />
<RankingSection models={...} />     — TOP 10
<EditorPickSection featured={...} runnersUp={...} />
<BrowseGenreSection categories={...} />
<NewArrivalsSection books={...} />
<FeatureArticlesSection articles={...} />
<NewsletterSignup />
<SiteFooter />
```

Atomic components:
```
<MagazineCard size="hero|large|small" {...} />
<PhotobookCard size="hero|small" {...} />
<ModelRankCard rank={n} trend="up|down|new" model={...} />
<GenreCard category={...} />
<FeatureArticleCard article={...} />
<AffiliateButton partner="amazon|rakuten|fanza" url={...} />
<ModelChip name={...} avatar={...} />
<PriceTag yen={...} showPR={true} />
<TagChip variant="default|alt|alt2" />
```

### Accessibility

- The hero rank numbers use `background-clip: text` for the gold/silver/bronze effect. Ensure the underlying `color` (white with shadow) remains readable if `background-clip` isn't supported — currently it falls back to white text on the gradient bg, which works.
- All nav and CTA elements need keyboard focus rings; the prototype omits them. Add `:focus-visible` outlines matching `var(--primary)`.
- The horizontal mobile scroller needs visible scrollbar or pagination dots — currently it relies on touch affordance only. Add either visual indicators or arrow buttons for keyboard/cursor users.
- Tags like "PR" should be inside `<span lang="en">` so screen readers don't read "ピーアール" awkwardly.
- The PR disclosure pill needs to be a real link to a disclosure page (currently visual-only in the prototype).

### Performance

- Magazine covers and portraits will be the heaviest assets. Implement `<picture>` with WebP+AVIF, lazy-load below the fold, and use blurhash/dominant-color placeholders matching the CSS-gradient style of the prototype.
- The footer and newsletter section can be Client Components; everything else above is RSC-friendly.

### Internationalization

- The prototype is JP-only. If multi-lingual is later in scope, structure copy keys around `ja` / `en` early. Note that the visual rhythm depends on Japanese punctuation (`・`) and 明朝 letter-spacing — English copy will need its own typography pass.

---

## Files in This Bundle

| File | Purpose |
|---|---|
| `Home.html` | The top page prototype — complete static markup. Open in a browser to interact. **Includes Tweaks panel** (right-bottom toggle) for switching hero variant / density / theme. |
| `Model.html` | Model detail page (example: 朝比奈 結衣) — profile, appearance timeline (8 most recent), popular photobooks (1 + 3 stacked), related models. |
| `Magazine.html` | Magazine/photobook detail page (example: Luna Weekly No.482) — large cover with thumbnail row, **3-way price comparison table** (Amazon / 楽天 / FANZA with stock & shipping), TOC, backnumber carousel, spec table. |
| `Models.html` | Models list — kana index, kana-grouped grid (4 groups × 4 cards), 4 facet sidebars (genre, era, cover count, photobook count). |
| `Magazines.html` | Magazines & photobooks list — type tabs (週刊 / 月刊 / 写真集 / 電子限定 / バックナンバー / 復刻 / 限定版), month-grouped big-card grid, 4 facet sidebars (publisher, year, price range, status). |
| `Ranking.html` | Ranking page — TOP 3 podium (with metals + quotes), numbered list for ranks 4-30, **Hall of Fame** section (殿堂入り 42名). |
| `Feature.html` | Long-form editorial article — full-bleed cover image, body with H2/H3/blockquote/figure, **inline affiliate product card**, related products, related articles. |
| `styles.css` | All site styles — design tokens (3 themes × density × component classes). Single shared stylesheet across all 7 pages. |
| `tweaks-panel.jsx` | React component that powers the live-preview Tweaks panel (in Home.html only). **Prototype scaffolding — do not ship.** In production these are user preferences or admin-controlled defaults. |
| `README.md` | This document. |

### Navigation map

All pages link to each other through:
- The top nav (`.nav-menu`) — 6 links
- The breadcrumb sub-nav (`.subnav` with `現在地`)
- The footer `EXPLORE` column

A user landing on any page can reach any other page within 1 click.

---

## Per-Page Spec Highlights

### `Model.html` — Model detail

**URL pattern**: `/models/[slug]` (e.g., `/models/asahina-yui`)

**Structure**:
1. Nav + breadcrumb
2. `.model-hero` — 320px square portrait (with 3:4 ratio inside) on the left, profile block on the right. Profile uses a `<dl>` grid (4-column: label / value / label / value) for 8 fields (生年月日, 出身地, 身長, サイズ, 血液型, 趣味, 所属, デビュー). Below are 5 inline stats (出演誌 / 写真集 / 表紙回数 / 今月ランキング / FAV count).
3. Recent appearances — 6-card `.arrivals` grid (reuses home-page component)
4. Popular photobooks — `.pickup` layout (1 large + 3 stacked, reused from home)
5. Full appearance log — `.timeline` table with date / 56px cover / mag-name + title + meta / partner buy button. 8 rows shown + "全248件を見る" CTA.
6. Related models — `.related-models` (5 × circular portrait cards)
7. "新刊が出たら通知" newsletter form
8. Footer

**Data shape**:
```ts
type Model = {
  slug: string
  name: string                  // 朝比奈 結衣
  nameYomi: string              // あさひな ゆい
  nameRomaji: string            // Asahina Yui
  birthdate: Date
  birthplace: string
  height_cm: number
  bwh?: string                  // "B87 W58 H86" — optional, display only with consent
  bloodType?: string
  hobbies: string[]
  agency: string
  debut: { date: Date, magazine: string, issue: string }
  tags: string[]                // ["グラビア","アイドル","女優"]
  lede: string                  // 2-3 sentence editorial intro
  stats: { issues: number, photobooks: number, covers: number, monthlyRank?: number, favorites: number }
  portraitGradient: { c1: string, c2: string, c3: string, c4: string }  // CSS-only fallback
  portraitImage?: string        // real image URL
  recentAppearances: Issue[]    // 6
  popularPhotobooks: Photobook[]  // 4 (1 featured + 3 ranked 2/3/4)
  appearanceLog: AppearanceEntry[] // full
  relatedModels: ModelStub[]    // 5
}
```

**Server rendering note**: Cache for 1h; revalidate when a new appearance is added to `appearanceLog`. The `monthlyRank` and `favorites` fields should be fetched fresh server-side.

### `Magazine.html` — Magazine / photobook detail

**URL pattern**: `/magazines/[slug]/[issue]` or `/photobooks/[slug]`

**Structure**:
1. Nav + breadcrumb (現在地 → 雑誌・写真集 → 週刊グラビア誌 → Luna Weekly → No.482)
2. `.mag-hero` — Left: 360px cover (rotated -1.5°) + 4-thumb gallery row underneath. Right: publisher line with `週刊` badge, large title, sub-title, 5 quick-fact pills (発売日 / 判型 / ページ数 / 掲載モデル数 / 電子版有無), **`.price-compare` table** (the main commercial CTA), and 3 small action buttons (お気に入り / あとで読む / 共有).
3. **`.price-compare` is the centerpiece**:
   - Head: title + "9分前に更新" timestamp
   - 3 rows for Amazon / 楽天 / FANZA, each with: partner logo + name / price (with point bonus on 楽天) / shipping or delivery method / stock status / buy button with PR mini-tag
   - Recommended row has a subtle background tint (`rgba(108,91,140,.04)`)
   - Foot: "本ページのリンクは広告を含みます — PR"
   - Stock states: `.stock-ok` (leaf green), `.stock-low` (amber), `.stock-out` (gray)
4. Featured models — `.appear-models` card with 4 small profile cards (56px circular portrait + name + page count)
5. Table of contents — `.toc` with 8 entries, each showing: page number / tag (巻頭/特集/連載/中綴じ/etc.) / content title / meta line
6. Backnumber carousel — horizontal `.backnums-scroll` with 9 mini covers (this issue + 8 previous), each linkable
7. Specifications — `.spec-table` `<dl>` rows (10 fields)
8. Footer

**Data shape**:
```ts
type Magazine = {
  slug: string
  publisher: string
  name: string                  // Luna Weekly
  issue: string                 // No.482 / vol.117 / 2026春 / 1st
  type: "weekly" | "monthly" | "photobook" | "digital-only" | "reissue" | "limited"
  releaseDate: Date
  title: string                 // "Luna Weekly No.482"
  subTitle: string              // feature copy
  coverGradient: { c1: string, c2: string }
  coverImage?: string
  galleryImages?: string[]      // 4 additional thumbs
  pages: number
  format: string                // "B5判 平とじ"
  isbn?: string
  jan?: string
  featureModels: ModelStub[]    // with pageCount per model
  toc: TocEntry[]
  prices: PriceOffer[]          // {partner, url, price, pricePoint?, stock, shipping, recommended}
  backnumbers: MagazineStub[]
  specs: { [key: string]: string }
}
type PriceOffer = {
  partner: "amazon" | "rakuten" | "fanza" | "ebookjapan" | ...
  url: string                   // affiliate URL — generated server-side
  price: number
  pointBonus?: number           // for rakuten
  stock: "ok" | "low" | "out"
  shipping: string              // "本日中に発送 / 明日着 (Prime)"
  recommended: boolean
}
```

**Critical: price/stock freshness**. Each partner has its own API and ToS:
- **Amazon PA-API** — 24h cache max for prices; respect TPS limits
- **楽天 Books API** — keys via dashboard; cache up to 60min
- **DMM API** (FANZA) — separate adult/general endpoints; cache 60min
- The "9分前に更新" string should be **real**, not faked. Refresh via background cron and stamp the timestamp.

### `Models.html` — Models list

**URL pattern**: `/models?kana=a&genre=gravure&sort=name`

**Structure**:
1. Nav + breadcrumb
2. `.page-hd` — page header with gradient, eyebrow + title + sub
3. `.list-toolbar` — result count + sort chips (五十音 / 人気 / 新着 / 表紙数 / 写真集数)
4. `.list-kana` — kana index (あかさたなはまやらわ + A-M + #), supports `.active` and `.disabled` states
5. `.list-layout` — 2-column grid (1fr / 240px):
   - Left: kana-grouped sections. Each group has `.group-sep` (large kana badge + count + decorative rule) followed by 4-card `.models-list` (4-column grid).
   - Right `<aside>`: 4 `.facets` cards (ジャンル / 活動年代 / 表紙起用 / 写真集刊行) with checkboxes and counts.
6. Pagination
7. Footer

**Data shape**: list of `ModelStub` with `{slug, name, nameYomi, tags, kana, coverCount, photobookCount, isFavorited, portraitGradient}`. Pagination via URL params (`page`, `kana`, `genre[]`, `era`, `coverCountMin`, `photobookCountMin`, `sort`).

### `Magazines.html` — Magazines & photobooks list

**URL pattern**: `/magazines?type=weekly&year=2026`

**Structure**:
1. Nav + breadcrumb
2. `.page-hd`
3. `.type-tabs` — 8 horizontal tabs with count badges
4. `.list-toolbar` — result count + sort (新着順 / 発売日 / 人気 / 価格 安い / 価格 高い)
5. `.list-layout` (1fr / 240px):
   - Left: month-grouped sections. Each `.group-sep` shows month-of-issue. Below, `.mags-list` 4-column grid of `.mag-card` items. Each card: 3:4 cover with mast + feature, then publisher / issue / models / price + shop.
   - Right `<aside>`: 4 `.facets` cards (出版社 / 発売年 / 価格帯 / 状態)
6. Pagination
7. Footer

### `Ranking.html` — Ranking

**URL pattern**: `/ranking?period=monthly&genre=all`

**Structure**:
1. Nav + breadcrumb
2. `.page-hd` (with集計対象期間)
3. `.type-tabs` — 8 tabs (今月のTOP / 先月 / 年間 / 殿堂入り + 4 genre-filtered tabs)
4. `.rk-podium` — 3-column TOP3 layout. Center card (`.p1`) is `transform: translateY(-12px)` to elevate it. Each card has: portrait + gold/silver/bronze medal + name + 3 stats + 1-sentence quote.
5. `.rk-rows` — vertical list for ranks 4-10 (then 11-30). Each `.rk-row` has: rank number (28px serif) / 80px square portrait / name + yomi + tags / stats (表紙 + 写真集) / trend pill (↑↓± / NEW).
6. `.hof` — Hall of Fame card with gold-edged crown icons. 6-column grid of `.hof-card` (square portrait + crown badge + name + "since" year). Currently 12 visible + CTA to see all 42.
7. Footer

**Scoring**: The page mentions "表紙起用・お気に入り数・ページ閲覧の3指標を加重合計したスコア". Implementation:
- `score = w1 * coverCount + w2 * favorites + w3 * pageViews`
- Suggested weights: `w1=10, w2=2, w3=0.01` (tune from data)
- Compute monthly via cron at 00:00 on the 1st
- Persist last 24 months for "先月" / "年間" views
- Hall of Fame: model qualifies after 3 consecutive months in TOP 10

### `Feature.html` — Feature article

**URL pattern**: `/features/[slug]`

**Structure**:
1. Nav + breadcrumb
2. `.article-hero` — centered. Tag pill + serif H1 (max 760px) + lede + byline (author / date / read-time / category)
3. `.article-cover` — full-bleed 16:8 image (margin-top: -32px overlaps the hero)
4. `.article-body` — narrow 720px-max prose column. Supports `<p>`, `<h2>` (3px-left-border primary), `<h3>` (plum), `<blockquote>` (rose-2 left border, paper-2 bg), `<figure>` (with extended -40px side margins for impact, `<figcaption>` below)
5. **`.product-inline`** — inline affiliate card embedded mid-article (96px cover + meta + price + Amazon CTA + PR label). Used when products mentioned in the article body
6. `.article-meta-foot` — action row (👍 役立った / あとで読む / 共有) + tags
7. "この記事で取り上げた商品" — 4-card `.arrivals` grid of products mentioned
8. "関連記事" — 3-card `.related-articles` grid
9. Newsletter signup
10. Footer

**Editorial conventions**:
- Use 明朝 (Noto Serif JP) for all article body text, line-height 2.0, letter-spacing .04em
- `<h2>` numbered headings ("1. ", "2. ") are conventional for "how-to" features
- Inline products **always** carry a `PR` label and visible affiliate disclosure
- Article body width capped at 720px for readability — `.product-inline` and `<figure>` may extend wider with negative margin

**Content management**: Articles authored in MDX or rich-text CMS. Inline products referenced by SKU/slug so prices stay live.

---
